<?php
// Lorsqu'un administrateur approuve un utilisateur
$user_id = $_GET['user_id']; // L'ID de l'utilisateur à valider

// Mettre à jour le statut dans la base de données
$query = "UPDATE utilisateurs SET status='validé' WHERE id=$user_id";
mysqli_query($conn, $query);

// Envoyer un email à l'utilisateur pour l'informer
// Fonction d'envoi d'email ici

// Redirection vers le tableau de bord
header('Location: admin_dashboard.php');
?>
