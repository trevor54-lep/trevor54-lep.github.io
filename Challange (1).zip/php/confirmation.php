// Exemple d'email en PHP
mail($email, "Votre compte a été validé", "Votre inscription a été approuvée. Vous pouvez maintenant vous connecter.");
