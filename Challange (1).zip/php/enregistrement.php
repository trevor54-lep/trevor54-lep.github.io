<?php
// Supposons que la connexion à la base de données soit déjà établie

// Récupération des données envoyées par le formulaire
$username = $_POST['username'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Sécurisation du mot de passe
$entity = $_POST['entity'];
$status = 'en attente'; // Le compte est en attente de validation par l'administrateur

// Insertion dans la base de données
$query = "INSERT INTO utilisateurs (username, email, password, entity, status) VALUES ('$username', '$email', '$password', '$entity', '$status')";
mysqli_query($conn, $query);

// Redirection vers une page de confirmation
header('Location: confirmation_page.php');
?>
