document.addEventListener("DOMContentLoaded", () => {
    // Gestion de la connexion
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            const errorMsg = document.getElementById("loginError");

            if (email === "" || password === "") {
                errorMsg.textContent = "Tous les champs sont requis.";
            } else {
                errorMsg.textContent = "";
                alert("Connexion réussie !");
            }
        });
    }

    // Gestion de l'inscription
    const registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const name = document.getElementById("name").value;
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;
            const errorMsg = document.getElementById("registerError");

            if (name === "" || email === "" || password === "") {
                errorMsg.textContent = "Tous les champs sont requis.";
            } else {
                errorMsg.textContent = "";
                alert("Inscription réussie !");
            }
        });
    }
});
document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const email = document.getElementById("email").value;
            const password = document.getElementById("password").value;

            if (email && password) {
                localStorage.setItem("userLoggedIn", "true"); // Sauvegarde la connexion
                window.location.href = "../offres/liste.html"; // Redirige vers la liste des offres
            } else {
                alert("Veuillez remplir tous les champs !");
            }
        });
    }
});
const express = require("express");
const nodemailer = require("nodemailer");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: "ton-email@gmail.com",
        pass: "ton-mot-de-passe-app" // Utilise un mot de passe d'application Gmail
    }
});

app.post("/api/password-reset", async (req, res) => {
    const { email } = req.body;

    if (!email) {
        return res.status(400).json({ message: "Email requis." });
    }

    try {
        const resetLink = `https://example.com/reset-password?email=${encodeURIComponent(email)}`;
        
        await transporter.sendMail({
            from: "ton-email@gmail.com",
            to: email,
            subject: "Réinitialisation de votre mot de passe",
            text: `Cliquez sur ce lien pour réinitialiser votre mot de passe : ${resetLink}`
        });

        res.json({ message: "Email envoyé !" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de l'envoi de l'email." });
    }
});

app.listen(3000, () => console.log("Serveur démarré sur http://localhost:3000"));
