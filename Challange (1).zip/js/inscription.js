document.getElementById("registerForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Collecter les données
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    // Envoi à un serveur (simulation ici)
    fetch('/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, status: 'en attente', role: 'user' })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Inscription réussie, en attente de validation');
        } else {
            alert('Erreur : ' + data.error);
        }
    });
});
