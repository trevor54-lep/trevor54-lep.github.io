const express = require('express');
const app = express();

// Exemple de base de données fictive
let users = [
    { id: 1, name: 'John Doe', email: 'john@example.com', status: 'en attente', role: 'user' },
    // autres utilisateurs
];

// Route pour afficher les utilisateurs en attente
app.get('/admin/users', (req, res) => {
    const pendingUsers = users.filter(user => user.status === 'en attente');
    res.json(pendingUsers);
});

// Route pour approuver un utilisateur
app.post('/admin/approve/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    const user = users.find(u => u.id === userId);
    
    if (user) {
        user.status = 'approuvé';
        res.json({ success: true });
    } else {
        res.json({ success: false, error: 'Utilisateur non trouvé' });
    }
});

// Route pour rejeter un utilisateur
app.post('/admin/reject/:id', (req, res) => {
    const userId = parseInt(req.params.id);
    const user = users.find(u => u.id === userId);
    
    if (user) {
        user.status = 'rejeté';
        res.json({ success: true });
    } else {
        res.json({ success: false, error: 'Utilisateur non trouvé' });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));
